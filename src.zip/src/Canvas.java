import javax.swing.*;
import java.awt.event.*;

public class Canvas extends JFrame implements KeyListener {

    private int x = 50;
    private int y = 50;
    private RunningBoy runningBoy = new RunningBoy();
    private JumpingBoy jumpingBoy = new JumpingBoy();

    Canvas(){
        setSize(700,500);
        setLayout(null);
        addKeyListener(this);
        setVisible(true);

        setBoundsOfRunningBoy();
        setBoundsOfJumpingBoy();
    }

    private void setBoundsOfJumpingBoy(){
        runningBoy.setBounds(x,y, runningBoy.getFirstSpriteWidth(), runningBoy.getFirstSpriteHeight());
        add(runningBoy);
    }

    private void setBoundsOfRunningBoy(){
        jumpingBoy.setBounds(x,y, jumpingBoy.getSecondSpriteWidth(), jumpingBoy.getSecondSpriteHeight());
        add(jumpingBoy);
    }

    @Override
    public void keyTyped(KeyEvent keyEvent) {

    }

    @Override
    public void keyPressed(KeyEvent keyEvent) {
        switch (keyEvent.getKeyCode()){
            case KeyEvent.VK_RIGHT:
                jumpingBoy.setVisible(false);
                runningBoy.setVisible(true);
                setBoundsOfRunningBoy();

                runningBoy.runAnim();
                runningBoy.setFirstSpriteXStart(runningBoy.getFirstSpriteXStart()+ runningBoy.getFirstSpriteWidth());
                break;
            case KeyEvent.VK_SPACE:
                runningBoy.setVisible(false);
                jumpingBoy.setVisible(true);
                setBoundsOfJumpingBoy();

                jumpingBoy.jumpAnim();
                jumpingBoy.setSecondSpriteXStart(jumpingBoy.getSecondSpriteXStart() + jumpingBoy.getSecondSpriteWidth());
                break;
        }
        runningBoy.repaint();
    }

    @Override
    public void keyReleased(KeyEvent keyEvent) {

    }
}