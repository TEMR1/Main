import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class JumpingBoy extends JPanel{
    private JumpAnimation jumpAnimation;

    private int secondSpriteXStart = -35;
    private int secondSpriteYStart = -280;

    //----------------------------------------------------------

    public int getSecondSpriteXStart() {
        return secondSpriteXStart;
    }

    public int getSecondSpriteYStart() {
        return secondSpriteYStart;
    }


    public void setSecondSpriteXStart(int xStart) {
        this.secondSpriteXStart = xStart;
    }

    public void setSecondSpriteYStart(int yStart) {
        this.secondSpriteYStart = yStart;
    }

    //--------------------------------------------------------------

    public int getSecondSpriteWidth(){
        return 110;
    }

    public int getSecondSpriteHeight(){
        return 320;
    }

    //--------------------------------------------------------------------

    public void jumpAnim() {
        jumpAnimation = new JumpAnimation();
        jumpAnimation.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        BufferedImage image;
        try {
            image = ImageIO.read(new File("src/res/558-5589021_sprite-sheets-animation-png-transparent-png.png"));
            g.drawImage(image, secondSpriteXStart, secondSpriteYStart, null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    class JumpAnimation extends Thread {
        @Override
        public void run() {
            int i = 0;
            while (true) {
                if (i == 7) {
                    i = 0;
                    setSecondSpriteXStart(-55);
                    return;

                }
                setSecondSpriteXStart(getSecondSpriteXStart() - getSecondSpriteWidth());
                repaint();
                i++;
                try {
                    Thread.sleep(1000 / 5);
                } catch (InterruptedException e) {
                    e.printStackTrace();

                }
            }
        }
    }
}
