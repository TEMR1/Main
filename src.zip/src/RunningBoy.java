import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class RunningBoy extends JPanel {
    private RunAnimation runAnimation;

    private int firstSpriteXStart = -55;
    private int firstSpriteYStart = -50;

    //-----------------------------------------------------------------

    public int getFirstSpriteXStart() {
        return firstSpriteXStart;
    }

    public int getFirstSpriteYStart() {
        return firstSpriteYStart;
    }

    //------------------------------------------------------------------------

    public void setFirstSpriteXStart(int xStart) {
        this.firstSpriteXStart = xStart;
    }

    public void setFirstSpriteYStart(int yStart) {
        this.firstSpriteYStart = yStart;
    }

    //-------------------------------------------------------------------------

    public int getFirstSpriteWidth() {
        return 115;
    }

    public int getFirstSpriteHeight() {
        return 150;
    }

    public void runAnim() {
        runAnimation = new RunAnimation();
        runAnimation.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        BufferedImage image;
        try {
            image = ImageIO.read(new File("src/res/558-5589021_sprite-sheets-animation-png-transparent-png.png"));
            g.drawImage(image, firstSpriteXStart, firstSpriteYStart, null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    class RunAnimation extends Thread {
        @Override
        public void run() {
            int i = 0;
            while (true) {
                if (i == 7) {
                    i = 0;
                    setFirstSpriteXStart(-55);
                    return;

                }
                setFirstSpriteXStart(getFirstSpriteXStart() - getFirstSpriteWidth());
                repaint();
                i++;
                try {
                    Thread.sleep(1000 / 5);
                } catch (InterruptedException e) {
                    e.printStackTrace();

                }
            }
        }
    }
}
